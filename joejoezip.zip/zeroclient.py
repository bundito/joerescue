import zmq
import random
import sys
import time

port = "5556"
context = zmq.Context()
socket = context.socket(zmq.PAIR)
socket.connect("tcp://10.0.0.53:5556")

while True:
    msg = socket.recv()
    print(msg)
    socket.send_string("client message to server2")
    time.sleep(1)