#!/usr/bin/env bash

cd /home/bundito/joe/joe
python3 radioclash.py $1 $2
