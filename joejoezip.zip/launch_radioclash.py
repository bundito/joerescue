import time
import subprocess

proc = subprocess.Popen("python3", "radio_clash.py")

