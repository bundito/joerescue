import DownloadListing

results = DownloadListing.get_json()

def get_results(self):
    return results