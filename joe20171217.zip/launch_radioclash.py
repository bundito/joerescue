import time
import subprocess

proc = subprocess.Popen("python3", "radioclash.py")

